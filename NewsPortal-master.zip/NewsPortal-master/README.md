# NewsPortal
Java, Spring Boot, Spring Security, OAuth2, Spring Data, MongoDB

# Installation
1) Install MongoDB
    - Linux: https://docs.mongodb.com/manual/administration/install-on-linux/
    - Windows: https://docs.mongodb.com/manual/tutorial/install-mongodb-on-windows/
    - MAC: https://docs.mongodb.com/manual/tutorial/install-mongodb-on-os-x/

2) Clone this project and open it in your IDE
3) Run project

# MongoDB Help
For MongoDB command list please visit https://docs.mongodb.com/manual/reference/command/

# Demo account details

- ADMIN
login: admin
password: password

- USER
login: user
password: password

Enjoy ;)



