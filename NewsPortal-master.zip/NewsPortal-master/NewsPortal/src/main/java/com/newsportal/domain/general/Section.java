package com.newsportal.domain.general;

public enum Section {
	NEWS, SPORT, BUSINESS, TECH, MOTO, KNOWLEDGE, ENTERTAINMENT, STYLE, UNASSIGNED
}